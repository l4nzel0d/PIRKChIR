while (true) {
    let wannaRegister = prompt("Желаете пройти регистрацию на сайте?");
    if (wannaRegister === "Да") {
        alert("Круто!");
        break;
    }
    else alert("Попробуй ещё раз");
}